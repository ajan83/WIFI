import os
import sys
from PyQt5 import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5 import uic
from PyQt5.QtCore import *
from PyQt5.QtNetwork import QHostAddress, QTcpSocket
from PyQt5.Qt import Qt
from PyQt5.QtCore import *


import numpy as np
import cv2
import cv2.aruco as aruco
import time


fps = 1
cap = cv2.VideoCapture(0)

global counter
counter=5
global enable_target_search
enable_target_search=0
global enable_automatic_rescue
enable_automatic_rescue=0



class Ui(QtWidgets.QMainWindow):
    
    def __init__(self):
        super(Ui, self).__init__()
        uic.loadUi('wifi_client.ui', self)
        # Network
        self.lineEditConnect.setText("192.168.131.168:8000")
        self.socket = QTcpSocket()
        self.lineEditLog.setText("log.csv")
        self.file = None
        self.label = self.findChild(QLabel,"label")
        # Connect signals/slots: Networking
        self.pushButtonConnect.clicked.connect(self.pushButtonConnect_clicked)
        self.socket.connected.connect(self.socket_connected)
        self.socket.disconnected.connect(self.socket_disconnected)
        self.socket.error.connect(self.socket_error)
        self.socket.readyRead.connect(self.socket_readyRead)
        # Connect signals/slots: Number buttons
        self.pushButton1.pressed.connect(self.pushButton1_pressed)
        self.pushButton1.released.connect(self.pushButton1_released)
        self.pushButton2.pressed.connect(self.pushButton2_pressed)
        self.pushButton2.released.connect(self.pushButton2_released)
        self.pushButton3.setCheckable(True)
        self.pushButton3.clicked.connect(self.pushButton3_changed)
        self.pushButton3.setStyleSheet("background-color : None")
        self.pushButton4.pressed.connect(self.pushButton4_pressed)
        self.pushButton4.released.connect(self.pushButton4_released)
        self.pushButtonArrowLeft.pressed.connect(self.pushButtonArrowLeft_pressed)
        self.pushButtonArrowLeft.released.connect(self.pushButtonArrowLeft_released)
        self.pushButtonArrowRight.pressed.connect(self.pushButtonArrowRight_pressed)
        self.pushButtonArrowRight.released.connect(self.pushButtonArrowRight_released)
        self.pushButtonArrowUp.pressed.connect(self.pushButtonArrowUp_pressed)
        self.pushButtonArrowUp.released.connect(self.pushButtonArrowUp_released)
        self.pushButtonArrowDown.pressed.connect(self.pushButtonArrowDown_pressed)
        self.pushButtonArrowDown.released.connect(self.pushButtonArrowDown_released)
        # Connect signals/slots: Log to file
        self.pushButtonLog.clicked.connect(self.pushButtonLog_clicked)
        
        #Timer 
        self.timer=QtCore.QTimer(timerType=Qt.PreciseTimer)
        self.timer.timeout.connect(self.img_process)
        self.timer.start(int(1000/fps))
        #Timer for Button Press Timing
        self.buttonTimer=QtCore.QTimer(timerType=Qt.PreciseTimer)
        self.buttonTimer.setSingleShot(True)
        self.buttonTimer.timeout.connect(self.SideControlStop)

    @pyqtSlot()
    def pushButtonConnect_clicked(self):
        if not self.socket.isOpen():
            param = self.lineEditConnect.text().split(':')
            if len(param) != 2:
                return
            self.socket.connectToHost(QHostAddress(param[0]), int(param[1]))
        else:
            self.socket.close()

    @pyqtSlot()
    def socket_connected(self):
        self.lineEditConnect.setEnabled(False)
        self.pushButtonConnect.setText('Disconnect')

    @pyqtSlot()
    def socket_disconnected(self):
        self.lineEditConnect.setEnabled(True)
        self.pushButtonConnect.setText('Connect')

    @pyqtSlot()
    def socket_error(self):
        msg = QtWidgets.QMessageBox()
        msg.setIcon(QtWidgets.QMessageBox.Warning)
        msg.setText(self.socket.errorString())
        msg.setWindowTitle('Network error')
        msg.setStandardButtons(QtWidgets.QMessageBox.Ok)
        msg.exec_()

    @pyqtSlot()
    def socket_readyRead(self):
        data = self.socket.readAll()
        if self.file is not None:
            data_str = str(data.data(), encoding='utf-8')
            if not data_str.endswith('\n'):
                data_str += '\n'
            self.file.write(data_str)
            
    def __controller_send(self, cmd):
        print(cmd)
        cmd_bytes = cmd.encode('utf-8')
        # Calculate checksum
        sum = 0
        for c in cmd_bytes:
            sum += c
        crc = (~sum & 0xff).to_bytes(1, byteorder='little')
        cmd_bytes += crc
        # Send if socket available
        if self.socket.isOpen():
            self.socket.write(cmd_bytes)

    @pyqtSlot()
    def pushButton1_pressed(self):
        self.__controller_send('!B11')
        global enable_automatic_rescue
        enable_automatic_rescue=1
        self.pushButton3.click()

    @pyqtSlot()
    def pushButton1_released(self):
        self.__controller_send('!B10')

    @pyqtSlot()
    def pushButton2_pressed(self):
        self.__controller_send('!B21')

    @pyqtSlot()
    def pushButton2_released(self):
        self.__controller_send('!B20') 

        
    @pyqtSlot()
    def pushButton3_changed(self):
        global enable_target_search
        global enable_automatic_rescue
        if self.pushButton3.isChecked():
            self.pushButton3.setStyleSheet("background-color : lightblue")
            self.pushButton1.setEnabled(False)
            self.pushButton2.setEnabled(False)
            self.pushButton4.setEnabled(False)
            self.pushButtonArrowLeft.setEnabled(False)
            self.pushButtonArrowRight.setEnabled(False)
            self.pushButtonArrowUp.setEnabled(False)
            self.pushButtonArrowDown.setEnabled(False)
            enable_target_search=1
            self.__controller_send('!B30')
        else:
            self.pushButton3.setStyleSheet("background-color : None")
            self.pushButton1.setEnabled(True)
            self.pushButton2.setEnabled(True)
            self.pushButton4.setEnabled(True)
            self.pushButtonArrowLeft.setEnabled(True)
            self.pushButtonArrowRight.setEnabled(True)
            self.pushButtonArrowUp.setEnabled(True)
            self.pushButtonArrowDown.setEnabled(True)
            enable_target_search=0
            enable_automatic_rescue=0
            self.__controller_send('!B31')
            
            
    @pyqtSlot()
    def pushButton4_pressed(self):
        self.__controller_send('!B41')

    @pyqtSlot()
    def pushButton4_released(self):
        self.__controller_send('!B40')

    @pyqtSlot()
    def pushButtonArrowLeft_pressed(self):
        self.__controller_send('!B71')

    @pyqtSlot()
    def pushButtonArrowLeft_released(self):
        self.__controller_send('!B70')

    @pyqtSlot()
    def pushButtonArrowRight_pressed(self):
        self.__controller_send('!B81')

    @pyqtSlot()
    def pushButtonArrowRight_released(self):
        self.__controller_send('!B80')

    @pyqtSlot()
    def pushButtonArrowUp_pressed(self):
        self.__controller_send('!B51')

    @pyqtSlot()
    def pushButtonArrowUp_released(self):
        self.__controller_send('!B50')

    @pyqtSlot()
    def pushButtonArrowDown_pressed(self):
        self.__controller_send('!B61')

    @pyqtSlot()
    def pushButtonArrowDown_released(self):
        self.__controller_send('!B60')

    @pyqtSlot()
    def pushButtonLog_clicked(self):
        if self.file is None:
            try:
                self.file = open(self.lineEditLog.text(), 'w')
                self.lineEditLog.setEnabled(False)
                self.pushButtonLog.setText('Disable')
            except Exception as ex:
                msg = QtWidgets.QMessageBox()
                msg.setIcon(QtWidgets.QMessageBox.Warning)
                msg.setText(str(ex))
                msg.setWindowTitle('File error')
                msg.setStandardButtons(QtWidgets.QMessageBox.Ok)
                msg.exec_()
        else:
            self.file.close()
            self.file = None
            self.lineEditLog.setEnabled(True)
            self.pushButtonLog.setText('Enable')
    
    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_W and not event.isAutoRepeat():
            self.pushButtonArrowUp_pressed() 
        if event.key() == QtCore.Qt.Key_S and not event.isAutoRepeat():
            self.pushButtonArrowDown_pressed() 
        if event.key() == QtCore.Qt.Key_A and not event.isAutoRepeat():
            self.pushButtonArrowLeft_pressed()
        if event.key() == QtCore.Qt.Key_D and not event.isAutoRepeat():
            self.pushButtonArrowRight_pressed() 
        if event.key() == QtCore.Qt.Key_1 and not event.isAutoRepeat():
            self.pushButton1_pressed()
        if event.key() == QtCore.Qt.Key_2 and not event.isAutoRepeat():
            self.pushButton2_pressed()
        if event.key() == QtCore.Qt.Key_3 and not event.isAutoRepeat():
            self.pushButton3.click()
        if event.key() == QtCore.Qt.Key_4 and not event.isAutoRepeat():
            self.pushButton4_pressed() 
    
    def keyReleaseEvent(self, event):
        if event.key() == QtCore.Qt.Key_W and not event.isAutoRepeat():
            self.pushButtonArrowUp_released()
        if event.key() == QtCore.Qt.Key_S and not event.isAutoRepeat():
            self.pushButtonArrowDown_released()
        if event.key() == QtCore.Qt.Key_A and not event.isAutoRepeat():
            self.pushButtonArrowLeft_released()
        if event.key() == QtCore.Qt.Key_D and not event.isAutoRepeat():
            self.pushButtonArrowRight_released()
        if event.key() == QtCore.Qt.Key_1 and not event.isAutoRepeat():
            self.pushButton1_released()
        if event.key() == QtCore.Qt.Key_2 and not event.isAutoRepeat():
            self.pushButton2_released()
        if event.key() == QtCore.Qt.Key_4 and not event.isAutoRepeat():
            self.pushButton4_released()
            
    def img_process(self):
        self.worker = WorkerThread()
        self.worker.start()
        self.worker.command.connect(self.SideControl)
        self.worker.change_pixmap.connect(self.label.setPixmap)
    
    def SideControl(self,command):
        global counter
        global enable_automatic_rescue
        if(enable_target_search):
            if(command=='!I33'):
                counter+=1
                if(counter>5):
                    self.__controller_send('!B71')
                    self.buttonTimer.start(500)
            elif(command=='!I12'):
                self.__controller_send('!B71')
                self.buttonTimer.start(40)
                counter=0
            elif(command=='!I22'):
                self.__controller_send('!B81')
                self.buttonTimer.start(40)
                counter=0
            elif(command=='!I11'):
                self.__controller_send('!B71')
                self.buttonTimer.start(40)
                counter=0
            elif(command=='!I21'):
                self.__controller_send('!B81')
                self.buttonTimer.start(40)
                counter=0
            elif(command=='!I99'):
                if(enable_automatic_rescue):
                    self.__controller_send('!B40')
                self.pushButton3.click()
                

    def SideControlStop(self):
        self.__controller_send('!B80')
        
        
    
class WorkerThread(QThread):
    command = pyqtSignal(str)
    change_pixmap = pyqtSignal(QPixmap)
    
    def run(self):
        ret, frame = cap.read()
        
        cv2.normalize(frame, frame, 0, 255, cv2.NORM_MINMAX)  # gives possibilty to change contrast
        frame = cv2.resize(frame, (1422, 800), fx=0, fy=0, interpolation=cv2.INTER_LINEAR_EXACT)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        aruco_dict = aruco.Dictionary_get(aruco.DICT_4X4_100)
        arucoParameters = aruco.DetectorParameters_create()
        corners, ids, rejectedImgPoints = aruco.detectMarkers(gray, aruco_dict, parameters=arucoParameters)
        frame = aruco.drawDetectedMarkers(frame, corners)
        #print("Coorindates of the Corners", corners)  # print out coordinates of the corners
        if np.all(ids is not None):
            display = aruco.drawDetectedMarkers(frame, corners)
            x1 = (corners[0][0][0][0], corners[0][0][0][1])
            x2 = (corners[0][0][1][0], corners[0][0][1][1])
            x3 = (corners[0][0][2][0], corners[0][0][2][1])
            x4 = (corners[0][0][3][0], corners[0][0][3][1])
            center = 0
            for i in range(len(corners[0][0])):
                center += corners[0][0][i]
            center /= 4
            
            # print("Midpoint", center)
            cv2.circle(frame, (int(center[0]), int(center[1])), 3, (0, 0, 255), -1)
        
            deviation = 1422 / 2 - center[0]
        else:
            deviation = 1000

        print(deviation)
        img_show=cv2.resize(frame,(711,400),frame)
        img_show=cv2.cvtColor(img_show,cv2.COLOR_BGR2RGB)  
        height, width, channel = img_show.shape
        bytesPerLine = 3 * width
        qImg = QImage(img_show.data, width, height, bytesPerLine, QImage.Format_RGB888)
        pixmap = QPixmap(qImg)
        self.change_pixmap.emit(pixmap)

        if(deviation<700 and deviation > 400):
            string='!I12'
        elif(deviation<400 and deviation > 100):
            string='!I11' 
        elif(deviation < -100 and deviation > -400):
            string='!I21'
        elif(deviation < -400 and deviation > -700):
            string='!I22'
        else:
            string='!I33'   
        if(abs(deviation) < 100):
            string='!I99'
            
        self.command.emit(string)
    
    
if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    window = Ui()
    window.setWindowTitle(os.path.basename(sys.argv[0]))
    window.show()
    app.exec_()



  